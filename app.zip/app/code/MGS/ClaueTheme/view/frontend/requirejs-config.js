var config = {
	config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'MGS_ClaueTheme/js/configurable': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'MGS_ClaueTheme/js/swatch-renderer': true
            }
        }
    }
};